declare global {
    interface Window {
        cordova: any;
    }
}