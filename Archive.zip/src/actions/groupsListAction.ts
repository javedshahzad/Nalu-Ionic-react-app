export const groupsListAction = (groups: any) => {
  return {
    type: "GROUPS_LIST",
    payload: groups,
  };
};
