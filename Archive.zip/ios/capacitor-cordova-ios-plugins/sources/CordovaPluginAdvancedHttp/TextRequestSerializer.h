#import <Foundation/Foundation.h>
#import "SM_AFURLRequestSerialization.h"

@interface TextRequestSerializer : SM_AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
