#import <Foundation/Foundation.h>
#import "SM_AFURLResponseSerialization.h"

@interface BinaryResponseSerializer : SM_AFHTTPResponseSerializer

+ (instancetype)serializer;

@end
